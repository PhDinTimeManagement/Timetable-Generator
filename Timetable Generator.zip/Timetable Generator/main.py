from collections import defaultdict
from itertools import product

available_courses_info = {
    "COMP1411": {
        "2011": {
            "lEC": [("Mon", 16.5, 18.5)],
            "TUT": [("Wed", 15.5, 16.5), ("Fri", 17.5, 18.5), ("Tue", 10.5, 11.5)]
        },
        "2012": {
            "LEC": [("Tue", 12.5, 14.5)],
            "TUT": [("Mon", 13.5, 14.5), ("Mon", 15.5, 16.5), ("Tue", 9.5, 10.5)]
        }
    },
    "COMP1433": {
        "2011": {
            "LTL": [("Thu", 12.5, 15.5)],
        },
        "2012": {
            "LTL": [("Fri", 18.5, 21.5)],
        }
    },
    "COMP2421": {
        "2011": {
            "lEC": [("Mon", 15.5, 18.5)],
            "LAB": [("Fri.", 12.5, 13.5), ("Fri.", 10.5, 11.5), ("Mon.", 12.5, 13.5)]
        },
        "2012": {
            "LEC": [("Tue", 15.5, 18.5)],
            "LAB": [("Fri", 11.5, 12.5), ("Thu", 16.5, 17.5), ("Fri", 14.5, 15.5)]
        }
    },
    "COMP2432": {
        "2011": {
            "LEC": [("Thu", 12.5, 15.5)],
            "LAB": [("Thu", 9.5, 10.5), ("Wed", 15.5, 16.5), ("Mon", 16.5, 17.5), ("Thu", 17.5, 18.5)]
        }
    },
    "ME1D02": {
        "2004": {
            "LTL": [("Thu", 18.5, 21.5)],
        }
    },
    "APSS2S09": {
        "2002N": {
            "LTL": [("Fri", 9.5, 12.5)],
        }
    }
}


def generate_course_combinations(available_course_info):
    course_combinations = defaultdict(list)

    for course, subject_groups in available_course_info.items():
        for subject_group, class_types in subject_groups.items():
            if "LTL" in class_types:
                course_combinations[course].append((subject_group, class_types["LTL"]))
            elif "LEC" in class_types:
                for lec in class_types["LEC"]:
                    other_classes = class_types.get("TUT", []) + class_types.get("LAB", [])
                    for other in other_classes:
                        course_combinations[course].append((subject_group, [lec, other]))
    return course_combinations


def find_best_combination(course_combinations):
    optimal_combination = None
    day_off = -1
    used_timeslots = defaultdict(lambda: False)

    for combination in product(*[course_combinations[course] for course in course_combinations]):
        schedule = defaultdict(int)
        clash_found = False

        for course_selection in combination:
            subject_group, classes = course_selection
            for cls in classes:
                if used_timeslots[(cls[0], cls[1], cls[2])]:
                    clash_found = True
                    break
                schedule[cls[0]] += 1
                used_timeslots[(cls[0], cls[1], cls[2])] = True
            if clash_found:
                break

        if not clash_found:
            free_days = 7 - len(schedule)
            if free_days > day_off:
                day_off = free_days
                optimal_combination = combination

        used_timeslots.clear()

    return optimal_combination, day_off


all_combinations = generate_course_combinations(available_courses_info)
best_combination, max_day_off = find_best_combination(all_combinations)

for course_info in best_combination:
    print(course_info)
print(f"Max Day Off: {max_day_off}")
